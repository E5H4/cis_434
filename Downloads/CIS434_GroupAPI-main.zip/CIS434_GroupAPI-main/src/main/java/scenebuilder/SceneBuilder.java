package scenebuilder;

import backend.Product;
import backend.User;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.Dictionary;
import java.util.Hashtable;

public class SceneBuilder extends Application {

    private TextArea resultArea;

    @Override
    public void start(Stage primaryStage) {
        // Initialize UI elements
        Button searchButton = new Button("Search");
        TextField searchField = new TextField();
        resultArea = new TextArea();
        resultArea.setEditable(false);

        // Layout setup
        VBox layout = new VBox(10);
        layout.getChildren().addAll(searchField, searchButton, resultArea);

        // Event handling
        searchButton.setOnAction(event -> {
            String searchTerm = searchField.getText();
            // Perform search and display results
            String searchResult = performSearch(searchTerm);
            resultArea.setText(searchResult);
        });

        // Scene setup
        Scene scene = new Scene(layout, 400, 300);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Inventory Management");
        primaryStage.show();
    }

    private String performSearch(String searchTerm) {
        StringBuilder searchResults = new StringBuilder();
        // Integrate your existing functionality here
        searchResults.append(searchUsers(searchTerm));
        searchResults.append(searchProducts(searchTerm));
        return searchResults.toString();
    }

    private String searchUsers(String searchTerm) {
        StringBuilder userResults = new StringBuilder("Users:\n");
        // Implement user search logic here
        // For demonstration, let's just return a dummy result
        ArrayList<User> users = User.search(new Hashtable<>());
        for (User user : users) {
            userResults.append(user.toString()).append("\n");
        }
        return userResults.toString();
    }

    private String searchProducts(String searchTerm) {
        StringBuilder productResults = new StringBuilder("Products:\n");
        // Implement product search logic here
        // For demonstration, let's just return a dummy result
        ArrayList<Product> products = Product.search(new Hashtable<>());
        for (Product product : products) {
            productResults.append(product.toString()).append("\n");
        }
        return productResults.toString();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
